import fitz

def fetch_input_file(file, filename):
    if filename.rsplit('.', 1)[1].lower() == 'pdf':
        pdf_file_obj = file
        pdf_doc = fitz.open(stream=pdf_file_obj.read(), filetype="pdf")
        file_content = ""
        for page in pdf_doc:
            file_content += page.get_text()
        return file_content

with open('static/files/sports.pdf', 'rb') as file:
    fetched_text = fetch_input_file(file, 'sports.pdf')
    print(fetched_text)

