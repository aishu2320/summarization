import pdfminer
import io
from io import StringIO
string_buffer = StringIO()
from pdfminer.converter import TextConverter
from pdfminer.layout import LAParams
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.pdfpage import PDFPage
from pdfminer.pdfparser import PDFParser
from bs4 import BeautifulSoup
import docx

def fetch_input_file(file, filename):
    # if filename.rsplit('.', 1)[1].lower() == 'pdf':
    #     pdf_file_obj = file
    #     pdf_resource_mgr = PDFResourceManager()
    #     string_io = io.StringIO()
    #     laparams = LAParams()
    #     device = TextConverter(pdf_resource_mgr,string_io, laparams=laparams)
    #     interpreter = PDFPageInterpreter(pdf_resource_mgr, device)
    #     for page in PDFPage.get_pages(pdf_file_obj):
    #         interpreter.process_page(page)
    #     file_content = string_io.getvalue()
    #     pdf_file_obj.close()
    #     device.close()
    #     string_io.close()
    #     soup = BeautifulSoup(file_content, 'html.parser')
    #     fetched_text = ' '.join(map(lambda p: p.text, soup.find_all('p')))
    #     return fetched_text
        # if filename.rsplit('.',1)[1].lower() in ('docx'):
        #  doc = docx.Document(file)
        #  fetched_text= ""
        #  for para in doc.paragraphs:
        #      fetched_text+= para.text
        #     #  fetched_text = ' '.join(map(lambda p: p.text, text.find_all('p')))
        # return fetched_text  
with open('static/files/sports.docx', 'rb') as file:
    fetched_text = fetch_input_file(file, 'sports.docx')
    # print('completed')
    print(fetched_text)
