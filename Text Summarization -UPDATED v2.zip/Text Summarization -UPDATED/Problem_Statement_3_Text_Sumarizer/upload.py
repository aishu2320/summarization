##file upload
@main_application.route('/upload')
def upload_file():
   return render_template('upload.html')
	
@main_application.route('/uploader', methods = ['GET', 'POST'])
def upload_file():
   if request.method == 'POST':
      f = request.files['file']
      f.save(secure_filename(f.filename))
        input_language = request.form['text_language']
        input_text = request.form['text_input_text']
        classifier_model_name = request.form['text_classifier']
        sentences_number = request.form['text_sentences_number']
        if input_language == 'english':
            classifier_model = pickle.load(open('models/en_' + classifier_model_name + '.pkl', 'rb'))
            text_summary, text_category = func.summarize_category(input_text, sentences_number, classifier_model, False)
        else:
            classifier_model = pickle.load(open('models/ar_' + classifier_model_name + '.pkl', 'rb'))
            text_summary, text_category = func.summarize_category(input_text, sentences_number, classifier_model, True)
    return render_template("index.html", page_title="Text Summarizer & Categorical", input_text=input_text, text_summary=text_summary, text_category=text_category)
      return 'file uploaded successfully'